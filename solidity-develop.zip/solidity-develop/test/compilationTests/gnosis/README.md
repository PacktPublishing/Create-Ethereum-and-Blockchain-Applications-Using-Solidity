Gnosis contracts, originally from

https://github.com/gnosis/gnosis-contracts
